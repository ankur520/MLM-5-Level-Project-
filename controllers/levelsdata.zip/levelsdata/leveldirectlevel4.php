
      <?php

  // sabse pehle mene apni id se sari direct id fetch kari 
  // phir direct id fetch karke auske direct ki id nikali jo ki mere 2 level per

  // LEVEL 1 id
              $level_1__SQLLLLL = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$myidno'");

              while ($row_SQLLLLL = mysqli_fetch_assoc($level_1__SQLLLLL)) {

                $L1_id_L2fetch_idds = $row_SQLLLLL['user_selfid'];
                $L1_id_L2fetch_namees = $row_SQLLLLL['user_signupFullName'];

                  // echo $L1_id_L2fetch_idds . " " . $L1_id_L2fetch_namees;
                  // echo "<br>";



  // here we are trying to level 2 id
                $level2_SQLLs = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$L1_id_L2fetch_idds'");

                while($row_dataas = mysqli_fetch_assoc($level2_SQLLs)) {

                  $L2idds = $row_dataas['user_selfid'];
                  $L2namees = $row_dataas['user_signupFullName'];

                   // echo $L2idds . " " . $L2namees . " ";
                   // echo "<br>";


// here we are trying for level 3
                  $level3_SQLs = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$L2idds'");

                  while ($rows_dataaaas = mysqli_fetch_assoc($level3_SQLs)) {
                    $L3id = $rows_dataaaas['user_selfid'];
                    $L3names = $rows_dataaaas['user_signupFullName'];

                   //   echo $L3id . " " . $L3names . " ";
                   // echo "<br>";


// here we are trying for level 4
                      $level4_SQL = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$L3id'");

                      while ($level4row = mysqli_fetch_assoc($level4_SQL)) {

                        $L4id = $level4row['user_selfid'];
                        $L4name = $level4row['user_signupFullName'];
                        $L4email = $level4row['user_signupEmail'];
                        $L4joiningdate = $level4row['user_signupUserDate'];
                        $L4useractive = $level4row['user_active'];

                        echo  "
                  <tr>
                  <th scope='row'> </th>
                  <td> $L4id </td>
                  <td> $L4name </td>
                  <td> $L4email </td>
                  <td> $L3names </td>
                  <td> $L4joiningdate </td>
                  <td> $L4useractive<br> </td>
                  </tr>
                  ";
                        
                      } //  END $row_dataa while loop 4th
                  
                  } // // END $row_dataa while loop 3rd

  } // END $row_dataa while loop 2nd

  } // END $row_SQLLL while loop 1st
  ?>
