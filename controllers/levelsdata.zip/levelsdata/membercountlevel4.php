
<?php

  // sabse pehle mene apni id se sari direct id fetch kari 
  // phir direct id fetch karke auske direct ki id nikali jo ki mere 2 level per

  // LEVEL 1 id
$level_1__SQLLLLL = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$myidno'");

while ($row_SQLLLLL = mysqli_fetch_assoc($level_1__SQLLLLL)) {

  $L1_id_L2fetch_idds = $row_SQLLLLL['user_selfid'];
  $L1_id_L2fetch_namees = $row_SQLLLLL['user_signupFullName'];

  // echo $L1_id_L2fetch_idds . " " . $L1_id_L2fetch_namees;
  // echo "<br>";



  // here we are trying to level 2 id
  $level2_SQLLs = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$L1_id_L2fetch_idds'");

  while($row_dataas = mysqli_fetch_assoc($level2_SQLLs)) {

    $L2idds = $row_dataas['user_selfid'];
    $L2namees = $row_dataas['user_signupFullName'];

  // echo $L2idds . " " . $L2namees . " ";
  // echo "<br>";


  // here we are trying for level 3
    $level3_SQLs = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$L2idds'");

    while ($rows_dataaaas = mysqli_fetch_assoc($level3_SQLs)) {
      $L3id = $rows_dataaaas['user_selfid'];
      $L3names = $rows_dataaaas['user_signupFullName'];

  //   echo $L3id . " " . $L3names . " ";
  // echo "<br>";


  // here we are trying for level 4
      $level4_SQL = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$L3id'");

      while ($level4row = mysqli_fetch_assoc($level4_SQL)) {

        $L4id = $level4row['user_selfid'];
        $L4name = $level4row['user_signupFullName'];

  // echo $L4id . " " . $L4name . "<br>";



        $L4_result = array();
        $L4_sql = mysqli_query($connection, "SELECT COUNT(*) as L4Totals FROM users WHERE user_SignupSponserId='$L3id'");
        $L4_sql_data = mysqli_fetch_array($L4_sql);
        $L4_result = $L4_sql_data['L4Totals'];
        $totalL4[] = $L4_result;


        $L4_result_active = array();
        $L4_sql_active = mysqli_query($connection, "SELECT COUNT(*) as L4Totals FROM users WHERE user_SignupSponserId='$L3id' AND user_active='Active'");
        $L4_sql_data_active = mysqli_fetch_array($L4_sql_active);
        $L4_result_active = $L4_sql_data_active['L4Totals'];
        $totalL4_active[] = $L4_result_active;




  } //  END $row_dataa while loop 4th

  } // // END $row_dataa while loop 3rd

  } // END $row_dataa while loop 2nd

  } // END $row_SQLLL while loop 1st

  $amount = 150;
  $L4Bonuspercent = 10;
  $L4Percentage = ($L4Bonuspercent / 100) * $amount;
  $L4TotalIncome = $L4Percentage *  array_sum($totalL4_active);

  ?>
