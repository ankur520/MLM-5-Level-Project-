
<?php 

$myidno = $_SESSION["loggedin_selfid"];

$level1_totalSQL = mysqli_query($connection, "SELECT COUNT(*) as L1total FROM users WHERE user_SignupSponserId='$myidno'");
$level1_activeSQL = mysqli_query($connection, "SELECT COUNT(*) as L1totalactive FROM users WHERE user_SignupSponserId='$myidno' AND user_active='Active'");

$amount = 150;
$L1Bonuspercent = 27;

$L1totaldata = mysqli_fetch_assoc($level1_totalSQL);
$L1totalactivee = mysqli_fetch_assoc($level1_activeSQL);

$L1total = $L1totaldata['L1total'];
$L1active = $L1totalactivee['L1totalactive'];
$L1subtract = $L1total - $L1active;
$L1Percentage = ($L1Bonuspercent / 100) * $amount;
$L1TotalIncome = $L1Percentage *  $L1active;
?>
