
<?php
// 56498

// sabse pehle mene apni id se sari direct id fetch kari 
// phir direct id fetch karke auske direct ki id nikali jo ki mere 2 level per


$level_1_SQL = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$myidno'");

while ($row_SQLL = mysqli_fetch_assoc($level_1_SQL)) {

$L1_id_L2fetch_id = $row_SQLL['user_selfid'];
$L1_id_L2fetch_name = $row_SQLL['user_signupFullName'];

 // echo $L1_id_L2fetch_id . " " . $L1_id_L2fetch_name;;
 // echo "<br>";

 $level2_SQL = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$L1_id_L2fetch_id'");

while($row_data = mysqli_fetch_assoc($level2_SQL)) {


  $L2id = $row_data['user_selfid'];
  $L2name = $row_data['user_signupFullName'];
  $L2email = $row_data['user_signupEmail'];
  $L2joiningdate = $row_data['user_signupUserDate'];
  $L2useractive = $row_data['user_active'];


// $level1_totalSQL = mysqli_query($connection, "SELECT COUNT(*) as L2total FROM users WHERE user_SignupSponserId='$L1_id_L2fetch_id'");
// $level2_totalSQLssfetch = mysqli_fetch_array($level1_totalSQL);
// $L2totals[] = $level2_totalSQLssfetch['L2total'];



   echo 
              "
              <tr>
              <th scope='row'> </th>
              <td> $L2id </td>
              <td> $L2name </td>
              <td> $L2email </td>
              <td> $L1_id_L2fetch_name </td>
              <td> $L2joiningdate </td>
              <td> $L2useractive<br> </td>
              </tr>
              ";

}}?>
