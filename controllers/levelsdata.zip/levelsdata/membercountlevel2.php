
<!-- L2 STARTS FROM HERE -->

<?php 

$level1_query = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$myidno'");

while ($level1row = mysqli_fetch_assoc($level1_query)) {


  $level1id = $level1row['user_selfid'];
  $name = $level1row['user_signupFullName'];

  $leve2_query = mysqli_query($connection, "SELECT * FROM users WHERE user_SignupSponserId='$level1id' LIMIT 1");

  while ($l2row = mysqli_fetch_assoc($leve2_query)) {

    $level2id = $l2row['user_selfid'];
    $level2name = $l2row['user_signupFullName'];

  // echo $level1id . " " . $level2name . "<br>";


  // total users in Level 2
    $L2count_result = array();
    $L2count_query = mysqli_query($connection, "SELECT COUNT(*) as L222222222 FROM users WHERE user_SignupSponserId='$level1id'");
    $L2count_row = mysqli_fetch_array($L2count_query);
    $L2count_result = $L2count_row['L222222222'];
    $L2total[] = $L2count_result;

  // total active users in level 2
    $L2count_result_active = array();
    $L2count_query_active = mysqli_query($connection, "SELECT COUNT(*) as L22 FROM users WHERE user_SignupSponserId='$level1id' AND user_active='Active'");
    $L2count_row_active = mysqli_fetch_array($L2count_query_active);
    $L2count_result_active = $L2count_row_active['L22'];
    $L2total_active[] = $L2count_result_active;

  }}

  $amount = 150;
  $L2Bonuspercent = 13;
  $L2Percentage = ($L2Bonuspercent / 100) * $amount;
  $L2TotalIncome = $L2Percentage *  array_sum($L2total_active);

  ?>

