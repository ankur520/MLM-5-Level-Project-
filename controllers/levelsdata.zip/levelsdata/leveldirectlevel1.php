  <?php 
            while ($row_SQLdata = mysqli_fetch_assoc($level1_SQL)) {
              $L1name = $row_SQLdata['user_signupFullName'];
              $L1email = $row_SQLdata['user_signupEmail'];
              $L1joiningDate = $row_SQLdata['user_signupUserDate'];
              $L1userActive = $row_SQLdata['user_active'];
              $L1useridno = $row_SQLdata['user_selfid'];

              echo 
              "
              <tr>
              <th scope='row'> </th>
              <td> $L1useridno </td>
              <td> $L1name </td>
              <td> $L1email </td>
              <td> $L1joiningDate </td>
              <td> $L1userActive </td>
              </tr>
              ";
            }
            ?>